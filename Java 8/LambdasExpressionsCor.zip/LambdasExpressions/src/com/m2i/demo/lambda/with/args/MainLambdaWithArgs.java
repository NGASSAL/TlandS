package com.m2i.demo.lambda.with.args;

interface Instrument {                        // 1. Interface
	void jouer(String titre);
}

interface Instrument2{
	void jouer(String titre, int duree);
}

public class MainLambdaWithArgs {
	
	public static void main(String[] args) {
		Instrument instrument = x -> System.out.println("Jouer titre: " + x) ;//(x) -> System.out.println("Jouer titre: " + x); // (String x) -> System.out.println("Jouer titre: " + x)
		instrument.jouer("Allleeeeezzzz les bleus");
		Instrument2 instrument2 = (x,y) -> {
			for (int i=0; i<y ; i++){
				System.out.println(x);
			}
		};
		instrument2.jouer("Chantent les Sardines...", 3);
	}
}
