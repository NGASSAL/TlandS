package com.m2i.classic;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

public class Developer {

	public Developer(String name, BigDecimal salary, int age, List<String> languages) {		
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.languages = languages;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public List<String> getLanguages() {
		return languages;
	}

	public void setLanguages(List<String> languages) {
		this.languages = languages;
	}
	
	public void add(String language) {
        this.languages.add(language);
    }


	private String name; 
	private BigDecimal salary;
	private int age;
	private List<String> languages;

}
