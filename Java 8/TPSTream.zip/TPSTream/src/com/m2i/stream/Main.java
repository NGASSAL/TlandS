package com.m2i.stream;

import com.m2i.classic.Developer;
import com.m2i.classic.TestSorting;

import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Developer> listDevs = TestSorting.getDevelopers();

		
		
		//Doc https://docs.oracle.com/javase/8/docs/api/java/util/stream/package-summary.html
		
		//1. Utiliser des m�thodes de la classe Stream pour trier les cette liste		
		
		//2. Construire une Map<String, List<Developper>> o� la cl� est un langage		
		
		//3. Lister tous les langages de programation connus des developpers
		
		//4. compter les langages de programmation connus des developpeurs		
		
		//5. Utiliser la methode peek() de stream pour lister afficher le nom des collaborateurs utilisant le langage java
		
		//6. Lister les developpeurs connaissant du scala
		
		//7. Le cout mensuel de tous les developpeurs
		
		//8. Le developpeur qui gagne le plus 
		
		//9. 
		
		
		
	}

}
