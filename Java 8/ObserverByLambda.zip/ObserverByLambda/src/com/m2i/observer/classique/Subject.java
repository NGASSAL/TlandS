package com.m2i.observer.classique;
public interface Subject{
 void registerObserver(Observer o);
 void notifyObservers(String tweet);
}