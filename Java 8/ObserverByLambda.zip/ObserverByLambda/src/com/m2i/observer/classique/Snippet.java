package com.m2i.observer.classique;

public class Snippet {
	public static void main(String[] args) {
	 Feed f = new Feed();
	 f.registerObserver(new NYTimes());
	 f.registerObserver(new Guardian());
	 f.registerObserver(new LeParisien());
	 f.notifyObservers("We caugth Xavier Dupont de Ligones...");
	}
}

