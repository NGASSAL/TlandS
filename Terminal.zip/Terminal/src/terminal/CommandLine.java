package terminal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ServiceLoader;

import terminal.command.spi.Command;

/**
 * 
 */
public class CommandLine
{
	// Constants
	public static final String PROMPT = "> ";
	public static final String EXIT_COMMAND = "quit";
	public static final String HELP_COMMAND = "help";
	public static final String RESET_COMMAND = "reset";

	private ServiceLoader<Command> commandLoader = ServiceLoader.load(Command.class);
	private Map<String, Command> commands = new HashMap<String, Command>();

	public static void main(String[] args) throws Exception
	{
		CommandLine commandLine = new CommandLine();
		commandLine.start();
	}

	private void initCommands()
	{
		// Discover and register the available commands
		commands.clear();
		commandLoader.reload();
		Iterator<Command> commandsIterator = commandLoader.iterator();
		while (commandsIterator.hasNext())
		{
			Command command = commandsIterator.next();
			commands.put(command.getId(), command);
		}
	}

	public void start() throws IOException
	{
		// Load the available commands
		initCommands();

		// Welcome message
		System.out.println("Welcome to the Flexible Interactive Console.");
		System.out.printf("To quit, enter '%s'.%n", CommandLine.EXIT_COMMAND);
		System.out.printf("To get help, enter '%s'.%n", CommandLine.HELP_COMMAND);

		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		String line = null;
		while (true)
		{
			// Read the console input
			System.out.print("\n" + CommandLine.PROMPT);
			line = reader.readLine();
			String[] lineTokens = line.split("\\s+", 2);
			String commandName = lineTokens[0];

			// Exit
			if (CommandLine.EXIT_COMMAND.equals(commandName))
			{
				break;
			}
			// Reset
			if (CommandLine.RESET_COMMAND.equals(commandName))
			{
				initCommands();
				continue;
			}
			// Help
			if (CommandLine.HELP_COMMAND.equals(commandName))
			{
				System.out.println("Available commands :");
				for (String availableCommand : commands.keySet())
				{
					System.out.println("- " + availableCommand);
				}
				continue;
			}

			// Process the command
			Command command = commands.get(commandName);
			if (command == null)
			{
				// Unknown command
				System.out.println("Invalid command.");
			}
			else
			{
				// Try to execute the command
				String result = null;
				try
				{
					result = command.process(lineTokens.length > 1 ? lineTokens[1] : null);
				}
				catch (IllegalArgumentException ex)
				{
					System.out.println("Invalid syntax.\n" + command.getHelp());
				}

				// Print out the result of the command processing
				if (result != null)
				{
					System.out.println(result);
				}
			}
		}
		reader.close();

		// Bye message
		System.out.println("Bye.");
	}

}
