package terminal.command.spi;

/**
 * Represents a single command for the command-line system
 */
public abstract class Command
{

	/**
	 * Returns the command's identifier. Letters only.
	 * @return the command's identifier
	 */
	public abstract String getId();

	/**
	 * Get the help or usage message.
	 * @return The help/usage message
	 */
	public abstract String getHelp();

	/**
	 * Process the command.
	 * @param input The parameters. May be null.
	 * @return The result. May be null.
	 * @throws IllegalArgumentException If the parameters are incorrect.
	 */
	public abstract String process(String input) throws IllegalArgumentException;
}
