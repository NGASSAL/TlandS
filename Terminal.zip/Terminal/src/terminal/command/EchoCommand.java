package terminal.command;

import terminal.command.spi.Command;

/**
 * Command that only sends back the input string
 */
public class EchoCommand extends Command
{
	public static final String COMMAND_NAME = "echo";

	@Override
	public String getId()
	{
		return EchoCommand.COMMAND_NAME;
	}

	@Override
	public String getHelp()
	{
		return "Usage : " + EchoCommand.COMMAND_NAME + " <string>";
	}

	@Override
	public String process(String input) throws IllegalArgumentException
	{
		if ((input == null) || (input.length() == 0))
		{
			throw new IllegalArgumentException();
		}
		return input;
	}
}
