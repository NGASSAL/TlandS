package terminal.command;

import terminal.command.spi.Command;

/**
 * 
 */
public class UppercaseCommand extends Command
{

	public static final String COMMAND_NAME = "uppercase";

	@Override
	public String getId()
	{
		return UppercaseCommand.COMMAND_NAME;
	}

	@Override
	public String getHelp()
	{
		return "Usage : " + UppercaseCommand.COMMAND_NAME + " <string>";
	}

	@Override
	public String process(String input) throws IllegalArgumentException
	{
		if ((input == null) || (input.length() == 0))
		{
			throw new IllegalArgumentException();
		}
		return input.toUpperCase();
	}

}
