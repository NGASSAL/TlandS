package terminal.command;

import terminal.command.spi.Command;

/**
 * Command that reverses the input string.
 */
public class ReverseCommand extends Command
{
	public static final String COMMAND_NAME = "reverse";

	@Override
	public String getId()
	{
		return ReverseCommand.COMMAND_NAME;
	}

	@Override
	public String getHelp()
	{
		return "Usage : " + ReverseCommand.COMMAND_NAME + " <string>";
	}

	@Override
	public String process(String input) throws IllegalArgumentException
	{
		if ((input == null) || (input.length() == 0))
		{
			throw new IllegalArgumentException();
		}
		return new StringBuilder(input).reverse().toString();
	}

}
