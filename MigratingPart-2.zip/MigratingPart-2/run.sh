java --module-path mods \
	--class-path lib/person.jar \
	--add-modules gson	\
	academy.learnprogramming.main.Main

