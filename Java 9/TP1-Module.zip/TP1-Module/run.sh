java --class-path out academy.learnprogramming.jokeapp.Main
