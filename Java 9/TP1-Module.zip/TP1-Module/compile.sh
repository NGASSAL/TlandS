javac --source-path src -d out $(find . -name '*.java')

#javac -d out src/academy/learnprogramming/jokeapp/Main.java \
#src/academy/learnprogramming/jokeserver/JokeServer.java \
#src/academy/learnprogramming/jokeserver/internal/Filter.java
