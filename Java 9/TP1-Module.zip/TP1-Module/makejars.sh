jar -c -f jars/JokeServer.jar  -C out .
jar -c -f jars/JokeServerApp.jar --main-class academy.learnprogramming.jokeapp.Main -C out  .
