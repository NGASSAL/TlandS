java --class-path jars/JokeServerApp.jar academy.learnprogramming.jokeapp.Main
