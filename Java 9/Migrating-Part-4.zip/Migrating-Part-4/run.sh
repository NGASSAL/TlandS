java --module-path mods  \
	--module main/academy.learnprogramming.main.Main

