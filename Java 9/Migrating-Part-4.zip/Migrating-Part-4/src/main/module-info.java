module main {
	requires models;
	requires gson;
}

