jdeps --generate-module-info gson-src/gson/src/main/java gson-2.8.1.jar 
