jar --create --file mods/models.jar \
	-C out/models .

jar --create --file mods/main.jar \
	-C out/main .