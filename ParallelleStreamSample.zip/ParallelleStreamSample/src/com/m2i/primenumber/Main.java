package com.m2i.primenumber;

import java.util.stream.IntStream;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			countPrime(1,150000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void countPrime(int start, int end) throws Exception {
	
		if(start < end && start >=1 ) {


			final long count = IntStream.range(start, end)
		            .parallel()
		            .filter(number -> isPrime(number)).count();
		    System.out.println("Count - " + count);
		}else {
			throw new Exception("Invalid range");
		}
		
	}
	 
	public static boolean isPrime(final int number) {
	    return number > 1
	            && IntStream.rangeClosed(2, (int) Math.sqrt(number)).noneMatch(
	                    divisor -> number % divisor == 0);
	}
}
