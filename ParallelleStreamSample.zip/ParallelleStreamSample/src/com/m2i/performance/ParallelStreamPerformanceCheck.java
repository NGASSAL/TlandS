package com.m2i.performance;
import java.util.ArrayList;
import java.util.List;


public class ParallelStreamPerformanceCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> numList = new ArrayList<Integer>();
        for (int i = 0; i < 1000; i++) {
        	numList.add(i);
        }
 
        // Process sequentiel
        long startTime = System.currentTimeMillis();
        numList.stream().forEach(i -> processData(i));
        long endTime = System.currentTimeMillis();
        double sequentialStreamTimetaken = (endTime - startTime) / 1000;
        System.out.println("Durée en utilisant des streams : " + sequentialStreamTimetaken);
 
        // Process parallèle
        startTime = System.currentTimeMillis();
        numList.parallelStream().forEach(i -> processData(i));
        endTime = System.currentTimeMillis();
        long parallelStreamTimetaken = (endTime - startTime) / 1000;
        System.out.println("Durée en utilisant des parallelStreams: " + parallelStreamTimetaken);
        System.out.println("Differential time : " + (sequentialStreamTimetaken - parallelStreamTimetaken));
    }
 
    private static void processData(Integer num) {
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	}


}