package com.m2i.processing;

import java.util.Arrays;
import java.util.stream.Stream;

public class ParallelAleaCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Stream");
		Stream.of("John", "Mike", "Ryan","Donald", "Matthew").forEach(System.out::println);

		System.out.println("parallele stream");
		Stream.of("John", "Mike", "Ryan","Donald", "Matthew").parallel().forEach(System.out::println);

	}

}
