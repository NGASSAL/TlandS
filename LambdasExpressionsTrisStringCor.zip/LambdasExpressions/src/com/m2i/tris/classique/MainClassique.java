package com.m2i.tris.classique;

import java.util.Arrays;
import java.util.List;

public class MainClassique {
	
	public static void main(String[] args) {
		List<String> listStrings = Arrays.asList("Orange", "Grape", "Apple", "Lemon", "Banana");

		// - La longueur de chaque élément (length : de la plus longue  à la plus courte )
		listStrings.sort((a,b)->a.length() - b.length());
		System.out.println("l->L: "+listStrings);

		// - La longueur de chaque élément (length : de la plus courte à la plus longue )
		listStrings.sort((a,b) -> 0 - (a.length() - b.length()));
		System.out.println("L->l: "+listStrings);

		//par ordre alphabétique

		listStrings.sort((a,b) -> a.compareTo(b));
		System.out.println("a -> Z: "+listStrings);

		//Contenant e en premier
		listStrings.sort((a,b) -> a.contains("e") && !b.contains("e") ?-1: a.contains("e") && b.contains("e")?0:1);
		System.out.println("~e~ first: "+listStrings);


	}
}