package com.m2i.demo.lambda;

interface Instrument {                        // 1. Interface
	void jouer();
}


public class MainLambda {
	
	public static void main(String[] args) {
		Instrument instrument = () -> System.out.println("SAX SAX SAX...");
		instrument.jouer();
	}
}
