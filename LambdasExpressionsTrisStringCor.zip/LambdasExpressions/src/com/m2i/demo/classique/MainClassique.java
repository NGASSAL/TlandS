package com.m2i.demo.classique;

interface Instrument {                        // 1. Interface 
	void jouer();
}

class Saxophone implements Instrument{		   // 2. Implementation 
	public void jouer() {
		System.out.println("SAX SAX SAX...");
	}
}

public class MainClassique {
	
	public static void main(String[] args) {
		Instrument instrument = new Saxophone();
		instrument.jouer();
	}
}
