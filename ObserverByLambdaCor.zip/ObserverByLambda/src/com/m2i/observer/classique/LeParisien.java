package com.m2i.observer.classique;
public class LeParisien implements Observer{
 @Override
 public void inform(String tweet) {
  if(tweet != null && (tweet.matches("(.*)Dupont(.*)")) ){
   System.out.println("On a arr�t� de Ligones!!! \nLa preuve? \nCette source : " + tweet);
  }
 }
}