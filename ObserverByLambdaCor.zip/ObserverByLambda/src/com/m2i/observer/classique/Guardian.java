package com.m2i.observer.classique;
public class Guardian implements Observer{
 @Override
 public void inform(String tweet) {
  if(tweet != null && tweet.matches("(.*)ADN confirmed(.*)Dupont(.*)")){
   System.out.println("Yet another news in London... " + tweet);
  }
 }
}

