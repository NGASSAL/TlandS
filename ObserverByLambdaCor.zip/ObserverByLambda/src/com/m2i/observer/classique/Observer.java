package com.m2i.observer.classique;
public interface Observer {
     void inform(String tweet);
}