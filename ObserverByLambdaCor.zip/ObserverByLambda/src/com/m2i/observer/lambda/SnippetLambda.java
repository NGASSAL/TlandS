package com.m2i.observer.lambda;


import com.m2i.observer.classique.Feed;

public class SnippetLambda {
	public static void main(String[] args) {

		 Feed feedLambda = new Feed();

		 feedLambda.registerObserver((String tweet) -> {
		  if(tweet != null && tweet.contains("money")){
		   System.out.println("Breaking news in NY! " + tweet); }
		 });
		 feedLambda.registerObserver((String tweet) -> {
		  if(tweet != null && tweet.contains("queen")){
		   System.out.println("Yet another news in London... " + tweet); }
		 });

		 feedLambda.notifyObservers("Money money money, give me money!");
	}
}
