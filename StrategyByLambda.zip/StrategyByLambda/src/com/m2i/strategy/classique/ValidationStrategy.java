package com.m2i.strategy.classique;

public interface ValidationStrategy {
        public boolean execute(String s);
    }