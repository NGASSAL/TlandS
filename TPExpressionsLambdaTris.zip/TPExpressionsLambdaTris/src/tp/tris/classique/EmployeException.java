package tp.tris.classique;
public class EmployeException extends Exception {
  public EmployeException(String message) {
    super(message);
  }
} 